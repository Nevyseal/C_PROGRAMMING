#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    for(a = 1;a < 25; a++)
        {
            printf("\tGod bless Kenya\n");
        }
    return 0;
}
