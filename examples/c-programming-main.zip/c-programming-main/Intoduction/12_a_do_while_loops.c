#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 1;

    do{
            printf("\tGod bless Kenya\n");
            x++;
    }while(x<25);

    return 0;
}
