#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    while(a<25)
    {
        printf("\tGod bless Kenya\n");
        a++;
    }
    return 0;
}
