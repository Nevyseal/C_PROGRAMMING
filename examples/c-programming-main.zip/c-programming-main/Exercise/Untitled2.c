#include <stdio.h>

void main()
{
    int number, squareroot = 1, result;

    printf("\nEnter a number: ");
    scanf("%d", &number);

    while((result != number) && (result < num))
    {
    }
}
